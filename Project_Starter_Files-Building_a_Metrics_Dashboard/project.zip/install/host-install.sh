vagrant scp manifests/other/jaeger-all-in-one.yaml jaeger-all-in-one.yaml
vagrant scp manifests/app/backend.yaml backend.yaml
vagrant scp manifests/app/frontend.yaml frontend.yaml
vagrant scp manifests/app/trial.yaml trial.yaml
vagrant scp install/guest-install.sh guest-install.sh